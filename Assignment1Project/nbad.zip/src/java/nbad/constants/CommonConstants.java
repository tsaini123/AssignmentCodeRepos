package nbad.constants;

public class CommonConstants {
   public static final String ACTION_PARAM = "action"; 
   public static final String EMAIL_PARAM = "email"; 
   
}
