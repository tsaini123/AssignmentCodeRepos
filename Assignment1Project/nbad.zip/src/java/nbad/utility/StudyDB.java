package nbad.utility;
import java.util.ArrayList;
import nbad.business.Study;

public class StudyDB {
 public Study getStudy(String studyCode){
     return null;     
 }
 
 public ArrayList<Study> getStudies(){
     return null;
 }
 
 
 public ArrayList<Study> getStudies(String email){
     return null;
 }
 
 public void addStudy(Study study){
     
 }
 
 public void updateStudy(String sCode, Study study){
     
 }
 
}
